# Read-only Windows diagnostics. Run locally; review output before sharing.
$os = Get-CimInstance Win32_OperatingSystem
[pscustomobject]@{
    OS = $os.Caption
    Build = $os.BuildNumber
    LastBoot = $os.LastBootUpTime
    FreeMemoryMB = [math]::Round($os.FreePhysicalMemory / 1024)
}
Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | Select-Object DeviceID, @{N='FreeGB';E={[math]::Round($_.FreeSpace/1GB,2)}}
Get-WinEvent -FilterHashtable @{LogName='System'; Level=1,2; StartTime=(Get-Date).AddDays(-2)} -MaxEvents 20 -ErrorAction SilentlyContinue | Select-Object TimeCreated, Id, ProviderName
