param([string]$Target = 'example.com', [int]$Port = 443)
# Read-only checks against an authorized target.
Get-NetIPConfiguration | Select-Object InterfaceAlias, IPv4Address, IPv4DefaultGateway
Resolve-DnsName -Name $Target -ErrorAction Continue
Test-NetConnection -ComputerName $Target -Port $Port -InformationLevel Detailed
